# am_i_connected
This python3 package is the simplest way to check if there is internet connection.
